<!DOCTYPE html>
<html>
<head>
    <title>Venue and Facility Reservation System</title>
   <link rel="stylesheet" href="stylesss.css">
    </style>
</head>
<body>
    <div class="container">

        <table boarder cellpadding="1">
            <tr>
                <h2><td><img src="aulogo.png" width="200" height="200"></td>
                <a><th colspan="1">Venue and Facility, Reservation System for OSA JAS Campus</th> </a>
                <td><img src="osa.png" width="200" height="200"></td></h2>
                <td><th><p> Venue and Facility Reservation System

Welcome to the Venue and Facility Reservation System for OSA at JAS Campus! We are thrilled to offer our students and faculty a convenient way to book various facilities for their events and activities. Below are the details of the venues and facilities available for reservation:

Car Parking:
Location: Adjacent to the Main Entrance
Capacity: 50 parking spaces
Reservation: Car parking spaces can be reserved on a first-come, first-served basis by submitting a request through the reservation system. Please specify the date and duration of your reservation.
Basketball Court:
Location: Behind the Annex Building
Features: Standard basketball court with markings and hoops
Reservation: The basketball court can be reserved for friendly matches, tournaments, or practice sessions. Please indicate the date, time, and purpose of the reservation when making a request.
Quadrangle:
Location: Central area surrounded by academic buildings
Features: Open space suitable for outdoor events, gatherings, and performances
Reservation: The quadrangle is available for various events such as cultural festivals, concerts, and fairs. To reserve this space, kindly provide details about your event, including the estimated number of attendees and any special requirements.
Annex Building:
Location: Next to the Quadrangle
Features: Multi-purpose hall with seating capacity for 100 people
Reservation: The Annex Building is suitable for seminars, workshops, meetings, and small-scale events. Reservation requests should include the date, time, expected attendance, and any audiovisual equipment needed.
AVR (Audio-Visual Room):
Location: Ground floor of the Main Building
Features: Equipped with audiovisual equipment for presentations, screenings, and lectures
Reservation: The AVR can be reserved for academic purposes such as lectures, film screenings, and multimedia presentations. Please specify the date, time, duration, and technical requirements when making a reservation.
Reservation Process:

To make a reservation, log in to the Venue and Facility Reservation System using your student or faculty credentials.
Select the desired venue or facility from the list of options.
Fill out the reservation form with the required details, including date, time, purpose, and any special requirements.
Submit the request, and our team will review it and confirm the reservation via email.
For any inquiries or assistance regarding venue reservations, please contact the Office of Student Affairs.

Thank you for choosing our Venue and Facility Reservation System. We look forward to hosting your events at JAS Campus!






</p></td></th>
            </tr>
</table>
</body>
</html>