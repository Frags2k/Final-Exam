<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $reservation = $_POST['reservation'];
    $email = $_POST['email'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    
    // Database connection
    $servername = "con";
    $name = "name";
    $reservation = "reservation";
    $email = "email";
    $date = "date";
    $time = "time";

    // Create connection
    $conn = new mysqli($name, $reservation, $email, $date, $time);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL to insert data into database
    $sql = "INSERT INTO reservations (name, reservation, email, date, time) VALUES ('$name', '$reservation', '$email', '$date', '$time')";

    if ($conn->query($sql) === TRUE) {
        echo "Reservation submitted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close connection
    $conn->close();
}
?>
