
<!DOCTYPE html>
<html>
<head>
    <title>Venue and Facility Reservation System</title>
   <link rel="stylesheet" href="styless.css">
    
</head>
<body>
    <div class="container">

        <table boarder cellpadding="10">
            <tr>
                <h2><td><img src="aulogo.png" width="200" height="200"></td>
                <a><th colspan="2">Venue and Facility, Reservation System for OSA JAS Campus</th> </a>
                <td><img src="osa.png" width="200" height="200"></td></h2>
            </tr>
            <tr>
                <td colspan="4"><img src="sched.jpg" width="200" height="200"></td>
            </tr>
            <tr>
                <td colspan="4"><h2><a href="HomePage.php">Schedule your Reservation</a></h2></td>
            </tr>
            <tr>
                <td colspan="4"><img src="adm.jpg" width="200" height="200"></td>
            </tr>
            <tr>
                <td colspan="4"><h2><a href="login.php">Administrator Log-in</a></h2></td>
            </tr>
            <tr>
                <td colspan="4"><img src="inf.jpg" width="200" height="200"></td>
            </tr>
            <tr>
                <td colspan="4"><h2><a href="about.php">About</a></h2></td>
            </tr>
            
        </table>
    </div>
</body>
</html>
